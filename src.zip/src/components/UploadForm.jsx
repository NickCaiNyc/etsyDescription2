import React, { useState } from "react";
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { storage, auth } from "../firebase"; // Ensure Firebase is correctly configured

function UploadForm() {
  const [files, setFiles] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [uploading, setUploading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!auth.currentUser) {
      alert("You must be logged in to upload files.");
      return;
    }
    if (files.length === 0) {
      alert("Please select at least one file.");
      return;
    }

    setUploading(true);
    const userId = auth.currentUser.uid;
    const folderName = `uploads/${userId}/`; // 🔹 Store in user-specific folder
    const uploadedUrls = [];

    try {
      for (const file of files) {
        const uniqueSuffix = `${Date.now()}-${file.name}`;
        const fileRef = ref(storage, `${folderName}${uniqueSuffix}`);
        const uploadTask = uploadBytesResumable(fileRef, file);

        await new Promise((resolve, reject) => {
          uploadTask.on(
            "state_changed",
            (snapshot) => {
              const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
              console.log(`Uploading ${file.name}: ${progress.toFixed(2)}%`);
            },
            (error) => {
              console.error(`Upload failed for ${file.name}:`, error);
              reject(error);
            },
            async () => {
              const url = await getDownloadURL(uploadTask.snapshot.ref);
              console.log(`✅ Uploaded: ${url}`);
              uploadedUrls.push(url);
              resolve();
            }
          );
        });
      }

      console.log("🔥 All files uploaded successfully!", uploadedUrls);

      alert("✅ Upload successful!");
      setFiles([]);
      setUserInput(""); // Clear input
    } catch (error) {
      console.error("❌ Error during upload:", error);
      alert("Upload failed. Try again.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="file" multiple onChange={(e) => setFiles([...e.target.files])} disabled={uploading} required />
      <input
        type="text"
        value={userInput}
        onChange={(e) => setUserInput(e.target.value)}
        placeholder="Enter description"
        disabled={uploading}
      />
      <button type="submit" disabled={uploading}>{uploading ? "Uploading..." : "Upload"}</button>
      <button type="button" onClick={() => setFiles([])} disabled={uploading}>Clear</button>
    </form>
  );
}

export default UploadForm;
